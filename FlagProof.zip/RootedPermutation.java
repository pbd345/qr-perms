/*This program defines "RootedPermutation" objects and includes methods for
generating all RootedPermutation objects of a particular order and root
structure. A RootedPermutation object consists of a permutation, stored as
an array called "perm" and another array called "roots" which lists the indices
of the roots.*/

import java.util.ArrayList;

public class RootedPermutation
{
	int[]perm;
	int[]roots;

	//Constructor methods
	public RootedPermutation(int[]p)
	{
    perm=p;
		roots=new int[0];
  }
	public RootedPermutation(int[]p,int[]r)
	{
    perm=p;
		roots=r;
  }

	//A method for checking whether two rooted permutations are the same.
	public boolean same(RootedPermutation p)
	{
		return (same(this.perm,p.perm))&&(same(this.roots,p.roots));
	}

	public boolean same(int[]a, int[]b)
	{
		if(a.length!=b.length)
		{
			return false;
		}
		for(int i=0; i<a.length; i++)
		{
			if(a[i]!=b[i])
			{
				return false;
			}
		}
		return true;
	}

	public int length()
	{
		return perm.length;
	}

	public int numRoots()
	{
		return roots.length;
	}

	//A method for performing the "unrooting" operation. This operation is
	//typeset in LaTeX as \llbracket\cdot\rrbracket.

	public LinearCombination unroot()
	{
		return new LinearCombination(new RootedPermutation(perm, new int[0]), new Fraction(1,binom(perm.length,roots.length)));
	}

	//A simple method for representing a rooted permutation by a String. The roots
	//are surrounded by curly brackets.
	public String print()
	{
		String output="";

		for(int i=0; i<perm.length; i++)
		{
			boolean root=false;
			for(int j=0; j<roots.length; j++)
			{
				if(roots[j]==i)
				{
					root=true;
				}
			}
			if(root)
			{
				output=output+"{"+perm[i]+"}";
			}
			else
			{
				output=output+""+perm[i];
			}
		}
		return output;
	}

	public void rotate()
	{
		int[]tempP=new int[perm.length];
		for(int i=0; i<perm.length; i++)
		{
			tempP[i]=perm[i];
		}
		int[]tempR=new int[roots.length];
		for(int i=0; i<roots.length; i++)
		{
			tempR[i]=roots[i];
		}

		int rootIndex=0;

		for(int i=0; i<perm.length; i++)
		{
			perm[perm.length-tempP[i]]=i+1;
			for(int j=0; j<tempR.length; j++)
			{
				if(i==tempR[j])
				{
					roots[rootIndex]=perm.length-tempP[i];
					rootIndex++;
				}
			}
		}
		sort(roots);
	}

	//A simple recursive method for generating all permutations of order n in
	//lexicographic order.
	public static int[][] allPerms(int n)
	{
		if(n==0)
		{
			return new int[1][0];
		}
		int[][]shorter=allPerms(n-1);
		int[][]allPerms=new int[n*shorter.length][n];

		for(int first=1; first<=n; first++)
		{
			for(int p=0; p<shorter.length; p++)
			{
				allPerms[(shorter.length*(first-1))+p][0]=first;
				for(int i=1; i<n; i++)
				{
					if(shorter[p][i-1]<first)
					{
						allPerms[(shorter.length*(first-1))+p][i]=shorter[p][i-1];
					}
					if(shorter[p][i-1]>=first)
					{
						allPerms[(shorter.length*(first-1))+p][i]=shorter[p][i-1]+1;
					}
				}
			}
		}
		return allPerms;
	}

	//A simple method for exhaustively generating all tau-rooted permutations of
	//order n for a given permutation tau.
	public static RootedPermutation[] allRootedPerms(int n, int[]tau)
	{
		if(n<tau.length)
		{
			return new RootedPermutation[0];
		}
		ArrayList<RootedPermutation>rootedPermList=new ArrayList<RootedPermutation>();
		int[][]allPerms=allPerms(n);

		for(int p=0; p<allPerms.length; p++)
		{
			int[]roots=new int[tau.length];
			for(int i=0; i<tau.length; i++)
			{
				roots[i]=i;
			}

			while((roots.length>0)&&(roots[0]>=0))
			{
				boolean tauRooted=true;
				for(int i=0; i<roots.length; i++)
				{
					for(int j=i+1; j<roots.length; j++)
					{
						if((allPerms[p][roots[i]]-allPerms[p][roots[j]])*(tau[i]-tau[j]) <= 0)
						{
							tauRooted=false;
						}
					}
				}
				if(tauRooted)
				{
					rootedPermList.add(new RootedPermutation(allPerms[p],copy(roots)));
				}
				update(roots,n);
			}
			if(roots.length==0)
			{
				rootedPermList.add(new RootedPermutation(allPerms[p],roots));
			}
		}
		RootedPermutation[]rootedPerms=new RootedPermutation[rootedPermList.size()];
		for(int p=0; p<rootedPermList.size(); p++)
		{
			rootedPerms[p]=rootedPermList.get(p);
		}
		return rootedPerms;
	}

	//A method for replacing a subset of {0,...,max-1} with the subset of the same
	//cardinality that comes next in the lexicographic order.
	public static void update(int[]set, int max)
	{
		update(set,max,set.length-1);
	}

	public static void update(int[]set, int max, int index)
	{
		if(set[index]==max-set.length+index)
		{
			if(index>0)
			{
				update(set,max,index-1);
				return;
			}
			else
			{
				set[0]=-100;
				return;
			}
		}
		set[index]++;
		for(int i=index+1; i<set.length; i++)
		{
			set[i]=set[index]+i-index;
		}
	}

	//A method for constructing the multiplication table of all tau-rooted
	//permutations of order n.
	public static LinearCombination[][]multTable(int n, int[]tau)
	{
		RootedPermutation[]factors=allRootedPerms(n,tau);
		RootedPermutation[]products=allRootedPerms(2*n - tau.length, tau);

		LinearCombination[][]table=new LinearCombination[factors.length][factors.length];
		for(int i=0; i<table.length; i++)
		{
			for(int j=0; j<table.length; j++)
			{
				table[i][j]=new LinearCombination();
			}
		}

		int denom=binom(2*(n - tau.length),n - tau.length);

		//For each tau-rooted permutation of order 2*n - tau.length, we compute all
		//of the ways of "splitting" the non-root vertices to yield two
		//tau-rooted permutations of order n.
		for(int p=0; p<products.length; p++)
		{
			if(n==tau.length)
			{
				table[p][p]=new LinearCombination(products[p],new Fraction(1,1));
			}
			else
			{
				//The array "split" records the locations of the roots, labelled 0, and
				//the non-root vertices belonging to the first and second tau-rooted
				//permutations, respectively.
				int[]split=new int[2*n - tau.length];
				for(int i=0; i<split.length; i++)
				{
					split[i]=2;
				}
				for(int i=0; i<products[p].roots.length; i++)
				{
					split[products[p].roots[i]]=0;
				}
				int numOnes=0;
				for(int i=0; numOnes<n-tau.length; i++)
				{
					if(split[i]==2)
					{
						split[i]=1;
						numOnes++;
					}
				}

				while(split[0]>=0)
				{
					int[]firstPerm=new int[n];
					int[]firstRoots=new int[tau.length];
					int firstIndex=0;
					int firstRootIndex=0;
					for(int i=0; i<split.length; i++)
					{
						if(split[i]==0)
						{
							firstRoots[firstRootIndex]=firstIndex;
							firstRootIndex++;
						}
						if((split[i]==0)||(split[i]==1))
						{
							firstPerm[firstIndex]=products[p].perm[i];
							firstIndex++;
						}
					}

					for(int i=1; i<=n; i++)
					{
						int min=-10;
						int argMin=-10;
						for(int j=0; j<n; j++)
						{
							if((firstPerm[j]>=i)&&((min<0)||(firstPerm[j]<min)))
							{
								min=firstPerm[j];
								argMin=j;
							}
						}
						firstPerm[argMin]=i;
					}

					int[]secondPerm=new int[n];
					int[]secondRoots=new int[tau.length];
					int secondIndex=0;
					int secondRootIndex=0;
					for(int i=0; i<split.length; i++)
					{
						if(split[i]==0)
						{
							secondRoots[secondRootIndex]=secondIndex;
							secondRootIndex++;
						}
						if((split[i]==0)||(split[i]==2))
						{
							secondPerm[secondIndex]=products[p].perm[i];
							secondIndex++;
						}
					}

					for(int i=1; i<=n; i++)
					{
						int min=-10;
						int argMin=-10;
						for(int j=0; j<n; j++)
						{
							if((secondPerm[j]>=i)&&((min<0)||(secondPerm[j]<min)))
							{
								min=secondPerm[j];
								argMin=j;
							}
						}
						secondPerm[argMin]=i;
					}

					RootedPermutation first=new RootedPermutation(firstPerm,firstRoots);
					RootedPermutation second=new RootedPermutation(secondPerm,secondRoots);

					for(int i=0; i<factors.length; i++)
					{
						if(factors[i].same(first))
						{
							for(int j=0; j<factors.length; j++)
							{
								if(factors[j].same(second))
								{
									table[i][j].add(new LinearCombination(products[p].copy(),new Fraction(1,denom)));
								}
							}
						}
					}
					updateSplit(split);
				}
			}
		}
		return table;
	}

	public static void updateSplit(int[]split)
	{
		for(int i=split.length-1; i>=0; i--)
		{
			if(split[i]==1)
			{
				int j=i+1;
				while((j<split.length)&&(split[j]==0))
				{
					j++;
				}
				if((j<split.length)&&(split[j]==2))
				{
					split[j]=1;
					split[i]=2;
					int countOnes=0;
					for(int k=j+1; k<split.length; k++)
					{
						if(split[k]==1)
						{
							countOnes++;
						}
						if(split[k]!=0)
						{
							split[k]=2;
						}
					}
					int ones=0;
					for(int k=j+1; ones<countOnes; k++)
					{
						if(split[k]==2)
						{
							split[k]=1;
							ones++;
						}
					}
					return;
				}
			}
		}
		split[0]=-100;
	}

	//A method for making a copy of an integer array.
	public static int[]copy(int[]a)
	{
		int[]copy=new int[a.length];
		for(int i=0; i<a.length; i++)
		{
			copy[i]=a[i];
		}
		return copy;
	}

	//A method for making a copy of a rooted permutation
	public RootedPermutation copy()
	{
		return new RootedPermutation(copy(perm), copy(roots));
	}

	//A method for generating binomial coefficients recursively via Pascal's
	//Identity.
	public static int binom(int n, int k)
	{
		if((k==0)||(k==n))
		{
			return 1;
		}
		return binom(n-1,k) + binom(n-1,k-1);
	}

	//A simple inefficient method for sorting an array.
	public static void sort(int[]a)
	{
		boolean sorted=false;
		while(!sorted)
		{
			sorted=true;
			for(int i=0; i<a.length-1; i++)
			{
				if(a[i]>a[i+1])
				{
					sorted=false;
					int temp=a[i];
					a[i]=a[i+1];
					a[i+1]=temp;
				}
			}
		}
	}
}
