/*The purpose of this program is to verify the flag algebra calculation in
the paper "Six Permutations Force Quasirandomness" by Crudele, Dukes and Noel.
This program computes d(\rho^*,pi) for every permutation of length 6 and all of
the terms [[x_i*x_j]] and [[y_i*y_j]] for all 1<=i,j<=5 as linear combinations
of permutations of length 6. It then computes the appropriate linear combination
of these quantities and verifies that it is equal to (11/24) times the sum of
all permutations pi in S_6 (as a formal linear combination).*/

public class FlagProofVerifier
{
	public static void main(String[] args)
	{
		//Computing the sum of d(rhoStar, pi)*pi over each permutation pi of order 6.
		int[][]permutations = RootedPermutation.allPerms(6);
		LinearCombination rhoStarDensity=new LinearCombination();
		for(int i=0; i<permutations.length; i++)
		{
			rhoStarDensity.add(new LinearCombination(new RootedPermutation(permutations[i],new int[0]),rhoStarDensity(permutations[i])));
		}
		rhoStarDensity.reduce();

		//Printing the sum of d(rhoStar, pi)*pi over each permutation pi of order 6.
		System.out.println("sum_{pi in S_6} d(rhoStar, pi)*pi = "+rhoStarDensity.print());
		System.out.println();

		RootedPermutation[]flagsOne=RootedPermutation.allRootedPerms(4,new int[]{0,1});
		LinearCombination[][]multTableOne=RootedPermutation.multTable(4,new int[]{0,1});

		RootedPermutation[]flagsTwo=RootedPermutation.allRootedPerms(4,new int[]{1,0});
		LinearCombination[][]multTableTwo=RootedPermutation.multTable(4,new int[]{1,0});

		//We hard-code the vector x.
		LinearCombination[]x = new LinearCombination[5];
		for(int i=0; i<5; i++)
		{
			x[i]=new LinearCombination();
		}
		x[0].add(new LinearCombination(new RootedPermutation(new int[]{1,2,3,4},new int[]{0,1}),new Fraction(1)));
		x[0].add(new LinearCombination(new RootedPermutation(new int[]{1,2,4,3},new int[]{0,1}),new Fraction(-1)));

		x[0].add(new LinearCombination(new RootedPermutation(new int[]{1,2,3,4},new int[]{0,3}),new Fraction(1)));
		x[0].add(new LinearCombination(new RootedPermutation(new int[]{1,3,2,4},new int[]{0,3}),new Fraction(-1)));

		x[0].add(new LinearCombination(new RootedPermutation(new int[]{1,2,3,4},new int[]{1,2}),new Fraction(1)));
		x[0].add(new LinearCombination(new RootedPermutation(new int[]{4,2,3,1},new int[]{1,2}),new Fraction(-1)));

		x[0].add(new LinearCombination(new RootedPermutation(new int[]{1,2,3,4},new int[]{2,3}),new Fraction(1)));
		x[0].add(new LinearCombination(new RootedPermutation(new int[]{2,1,3,4},new int[]{2,3}),new Fraction(-1)));

		x[0].add(new LinearCombination(new RootedPermutation(new int[]{1,3,4,2},new int[]{0,3}),new Fraction(1)));
		x[0].add(new LinearCombination(new RootedPermutation(new int[]{1,4,3,2},new int[]{0,3}),new Fraction(-1)));

		x[0].add(new LinearCombination(new RootedPermutation(new int[]{1,4,2,3},new int[]{0,1}),new Fraction(1)));
		x[0].add(new LinearCombination(new RootedPermutation(new int[]{1,4,3,2},new int[]{0,1}),new Fraction(-1)));

		x[0].add(new LinearCombination(new RootedPermutation(new int[]{2,3,1,4},new int[]{2,3}),new Fraction(1)));
		x[0].add(new LinearCombination(new RootedPermutation(new int[]{3,2,1,4},new int[]{2,3}),new Fraction(-1)));

		x[0].add(new LinearCombination(new RootedPermutation(new int[]{2,3,4,1},new int[]{0,1}),new Fraction(1)));
		x[0].add(new LinearCombination(new RootedPermutation(new int[]{2,3,1,4},new int[]{0,1}),new Fraction(-1)));

		x[0].add(new LinearCombination(new RootedPermutation(new int[]{2,3,4,1},new int[]{1,2}),new Fraction(1)));
		x[0].add(new LinearCombination(new RootedPermutation(new int[]{1,3,4,2},new int[]{1,2}),new Fraction(-1)));

		x[0].add(new LinearCombination(new RootedPermutation(new int[]{2,4,1,3},new int[]{0,3}),new Fraction(1)));
		x[0].add(new LinearCombination(new RootedPermutation(new int[]{2,1,4,3},new int[]{0,3}),new Fraction(-1)));

		x[0].add(new LinearCombination(new RootedPermutation(new int[]{3,1,2,4},new int[]{0,3}),new Fraction(1)));
		x[0].add(new LinearCombination(new RootedPermutation(new int[]{3,2,1,4},new int[]{0,3}),new Fraction(-1)));

		x[0].add(new LinearCombination(new RootedPermutation(new int[]{3,1,4,2},new int[]{1,2}),new Fraction(1)));
		x[0].add(new LinearCombination(new RootedPermutation(new int[]{2,1,4,3},new int[]{1,2}),new Fraction(-1)));

		x[0].add(new LinearCombination(new RootedPermutation(new int[]{3,4,1,2},new int[]{0,1}),new Fraction(1)));
		x[0].add(new LinearCombination(new RootedPermutation(new int[]{3,4,2,1},new int[]{0,1}),new Fraction(-1)));

		x[0].add(new LinearCombination(new RootedPermutation(new int[]{3,4,1,2},new int[]{2,3}),new Fraction(1)));
		x[0].add(new LinearCombination(new RootedPermutation(new int[]{4,3,1,2},new int[]{2,3}),new Fraction(-1)));

		x[0].add(new LinearCombination(new RootedPermutation(new int[]{4,1,2,3},new int[]{1,2}),new Fraction(1)));
		x[0].add(new LinearCombination(new RootedPermutation(new int[]{3,1,2,4},new int[]{1,2}),new Fraction(-1)));

		x[0].add(new LinearCombination(new RootedPermutation(new int[]{4,1,2,3},new int[]{2,3}),new Fraction(1)));
		x[0].add(new LinearCombination(new RootedPermutation(new int[]{1,4,2,3},new int[]{2,3}),new Fraction(-1)));

		x[1].add(new LinearCombination(new RootedPermutation(new int[]{1,2,3,4},new int[]{0,2}),new Fraction(1)));
		x[1].add(new LinearCombination(new RootedPermutation(new int[]{1,4,3,2},new int[]{0,2}),new Fraction(-1)));

		x[1].add(new LinearCombination(new RootedPermutation(new int[]{1,2,3,4},new int[]{1,3}),new Fraction(1)));
		x[1].add(new LinearCombination(new RootedPermutation(new int[]{3,2,1,4},new int[]{1,3}),new Fraction(-1)));

		x[1].add(new LinearCombination(new RootedPermutation(new int[]{2,3,4,1},new int[]{0,2}),new Fraction(1)));
		x[1].add(new LinearCombination(new RootedPermutation(new int[]{2,1,4,3},new int[]{0,2}),new Fraction(-1)));

		x[1].add(new LinearCombination(new RootedPermutation(new int[]{4,1,2,3},new int[]{1,3}),new Fraction(1)));
		x[1].add(new LinearCombination(new RootedPermutation(new int[]{2,1,4,3},new int[]{1,3}),new Fraction(-1)));

		x[2].add(new LinearCombination(new RootedPermutation(new int[]{1,2,4,3},new int[]{0,3}),new Fraction(1)));
		x[2].add(new LinearCombination(new RootedPermutation(new int[]{1,4,2,3},new int[]{0,3}),new Fraction(-1)));

		x[2].add(new LinearCombination(new RootedPermutation(new int[]{1,2,4,3},new int[]{1,2}),new Fraction(1)));
		x[2].add(new LinearCombination(new RootedPermutation(new int[]{3,2,4,1},new int[]{1,2}),new Fraction(-1)));

		x[2].add(new LinearCombination(new RootedPermutation(new int[]{1,3,2,4},new int[]{0,1}),new Fraction(1)));
		x[2].add(new LinearCombination(new RootedPermutation(new int[]{1,3,4,2},new int[]{0,1}),new Fraction(-1)));

		x[2].add(new LinearCombination(new RootedPermutation(new int[]{1,3,2,4},new int[]{1,3}),new Fraction(1)));
		x[2].add(new LinearCombination(new RootedPermutation(new int[]{2,3,1,4},new int[]{1,3}),new Fraction(-1)));

		x[2].add(new LinearCombination(new RootedPermutation(new int[]{1,3,4,2},new int[]{1,2}),new Fraction(1)));
		x[2].add(new LinearCombination(new RootedPermutation(new int[]{2,3,4,1},new int[]{1,2}),new Fraction(-1)));

		x[2].add(new LinearCombination(new RootedPermutation(new int[]{1,4,2,3},new int[]{2,3}),new Fraction(1)));
		x[2].add(new LinearCombination(new RootedPermutation(new int[]{4,1,2,3},new int[]{2,3}),new Fraction(-1)));

		x[2].add(new LinearCombination(new RootedPermutation(new int[]{2,1,3,4},new int[]{0,2}),new Fraction(1)));
		x[2].add(new LinearCombination(new RootedPermutation(new int[]{2,4,3,1},new int[]{0,2}),new Fraction(-1)));

		x[2].add(new LinearCombination(new RootedPermutation(new int[]{2,1,3,4},new int[]{1,3}),new Fraction(1)));
		x[2].add(new LinearCombination(new RootedPermutation(new int[]{3,1,2,4},new int[]{1,3}),new Fraction(-1)));

		x[2].add(new LinearCombination(new RootedPermutation(new int[]{2,1,4,3},new int[]{0,2}),new Fraction(1)));
		x[2].add(new LinearCombination(new RootedPermutation(new int[]{2,3,4,1},new int[]{0,2}),new Fraction(-1)));

		x[2].add(new LinearCombination(new RootedPermutation(new int[]{2,1,4,3},new int[]{0,3}),new Fraction(1)));
		x[2].add(new LinearCombination(new RootedPermutation(new int[]{2,4,1,3},new int[]{0,3}),new Fraction(-1)));

		x[2].add(new LinearCombination(new RootedPermutation(new int[]{2,1,4,3},new int[]{1,2}),new Fraction(1)));
		x[2].add(new LinearCombination(new RootedPermutation(new int[]{3,1,4,2},new int[]{1,2}),new Fraction(-1)));

		x[2].add(new LinearCombination(new RootedPermutation(new int[]{2,1,4,3},new int[]{1,3}),new Fraction(1)));
		x[2].add(new LinearCombination(new RootedPermutation(new int[]{4,1,2,3},new int[]{1,3}),new Fraction(-1)));

		x[2].add(new LinearCombination(new RootedPermutation(new int[]{2,3,1,4},new int[]{0,1}),new Fraction(1)));
		x[2].add(new LinearCombination(new RootedPermutation(new int[]{2,3,4,1},new int[]{0,1}),new Fraction(-1)));

		x[2].add(new LinearCombination(new RootedPermutation(new int[]{2,4,1,3},new int[]{2,3}),new Fraction(1)));
		x[2].add(new LinearCombination(new RootedPermutation(new int[]{4,2,1,3},new int[]{2,3}),new Fraction(-1)));

		x[2].add(new LinearCombination(new RootedPermutation(new int[]{3,1,2,4},new int[]{1,2}),new Fraction(1)));
		x[2].add(new LinearCombination(new RootedPermutation(new int[]{4,1,2,3},new int[]{1,2}),new Fraction(-1)));

		x[2].add(new LinearCombination(new RootedPermutation(new int[]{3,1,4,2},new int[]{1,3}),new Fraction(1)));
		x[2].add(new LinearCombination(new RootedPermutation(new int[]{4,1,3,2},new int[]{1,3}),new Fraction(-1)));

		x[3].add(new LinearCombination(new RootedPermutation(new int[]{1,3,2,4},new int[]{1,3}),new Fraction(1)));
		x[3].add(new LinearCombination(new RootedPermutation(new int[]{2,3,1,4},new int[]{1,3}),new Fraction(-1)));

		x[3].add(new LinearCombination(new RootedPermutation(new int[]{1,3,2,4},new int[]{2,3}),new Fraction(1)));
		x[3].add(new LinearCombination(new RootedPermutation(new int[]{3,1,2,4},new int[]{2,3}),new Fraction(-1)));

		x[3].add(new LinearCombination(new RootedPermutation(new int[]{1,3,4,2},new int[]{1,2}),new Fraction(1)));
		x[3].add(new LinearCombination(new RootedPermutation(new int[]{2,3,4,1},new int[]{1,2}),new Fraction(-1)));

		x[3].add(new LinearCombination(new RootedPermutation(new int[]{1,4,2,3},new int[]{2,3}),new Fraction(1)));
		x[3].add(new LinearCombination(new RootedPermutation(new int[]{4,1,2,3},new int[]{2,3}),new Fraction(-1)));

		x[3].add(new LinearCombination(new RootedPermutation(new int[]{2,1,3,4},new int[]{0,2}),new Fraction(1)));
		x[3].add(new LinearCombination(new RootedPermutation(new int[]{2,4,3,1},new int[]{0,2}),new Fraction(-1)));

		x[3].add(new LinearCombination(new RootedPermutation(new int[]{2,1,3,4},new int[]{0,3}),new Fraction(1)));
		x[3].add(new LinearCombination(new RootedPermutation(new int[]{2,3,1,4},new int[]{0,3}),new Fraction(-1)));

		x[3].add(new LinearCombination(new RootedPermutation(new int[]{2,1,3,4},new int[]{1,2}),new Fraction(1)));
		x[3].add(new LinearCombination(new RootedPermutation(new int[]{4,1,3,2},new int[]{1,2}),new Fraction(-1)));

		x[3].add(new LinearCombination(new RootedPermutation(new int[]{2,1,3,4},new int[]{1,3}),new Fraction(1)));
		x[3].add(new LinearCombination(new RootedPermutation(new int[]{3,1,2,4},new int[]{1,3}),new Fraction(-1)));

		x[3].add(new LinearCombination(new RootedPermutation(new int[]{2,1,4,3},new int[]{0,2}),new Fraction(1)));
		x[3].add(new LinearCombination(new RootedPermutation(new int[]{2,3,4,1},new int[]{0,2}),new Fraction(-1)));

		x[3].add(new LinearCombination(new RootedPermutation(new int[]{2,1,4,3},new int[]{0,3}),new Fraction(1)));
		x[3].add(new LinearCombination(new RootedPermutation(new int[]{2,4,1,3},new int[]{0,3}),new Fraction(-1)));

		x[3].add(new LinearCombination(new RootedPermutation(new int[]{2,1,4,3},new int[]{1,2}),new Fraction(1)));
		x[3].add(new LinearCombination(new RootedPermutation(new int[]{3,1,4,2},new int[]{1,2}),new Fraction(-1)));

		x[3].add(new LinearCombination(new RootedPermutation(new int[]{2,1,4,3},new int[]{1,3}),new Fraction(1)));
		x[3].add(new LinearCombination(new RootedPermutation(new int[]{4,1,2,3},new int[]{1,3}),new Fraction(-1)));

		x[3].add(new LinearCombination(new RootedPermutation(new int[]{2,3,1,4},new int[]{0,1}),new Fraction(1)));
		x[3].add(new LinearCombination(new RootedPermutation(new int[]{2,3,4,1},new int[]{0,1}),new Fraction(-1)));

		x[3].add(new LinearCombination(new RootedPermutation(new int[]{2,4,1,3},new int[]{0,1}),new Fraction(1)));
		x[3].add(new LinearCombination(new RootedPermutation(new int[]{2,4,3,1},new int[]{0,1}),new Fraction(-1)));

		x[3].add(new LinearCombination(new RootedPermutation(new int[]{3,1,2,4},new int[]{1,2}),new Fraction(1)));
		x[3].add(new LinearCombination(new RootedPermutation(new int[]{4,1,2,3},new int[]{1,2}),new Fraction(-1)));

		x[3].add(new LinearCombination(new RootedPermutation(new int[]{3,1,4,2},new int[]{1,3}),new Fraction(1)));
		x[3].add(new LinearCombination(new RootedPermutation(new int[]{4,1,3,2},new int[]{1,3}),new Fraction(-1)));

		x[4].add(new LinearCombination(new RootedPermutation(new int[]{1,3,2,4},new int[]{1,3}),new Fraction(1)));
		x[4].add(new LinearCombination(new RootedPermutation(new int[]{2,3,1,4},new int[]{1,3}),new Fraction(-1)));

		x[4].add(new LinearCombination(new RootedPermutation(new int[]{1,3,4,2},new int[]{0,2}),new Fraction(1)));
		x[4].add(new LinearCombination(new RootedPermutation(new int[]{1,2,4,3},new int[]{0,2}),new Fraction(-1)));

		x[4].add(new LinearCombination(new RootedPermutation(new int[]{1,4,2,3},new int[]{0,2}),new Fraction(1)));
		x[4].add(new LinearCombination(new RootedPermutation(new int[]{1,3,2,4},new int[]{0,2}),new Fraction(-1)));

		x[4].add(new LinearCombination(new RootedPermutation(new int[]{2,1,3,4},new int[]{0,2}),new Fraction(1)));
		x[4].add(new LinearCombination(new RootedPermutation(new int[]{2,4,3,1},new int[]{0,2}),new Fraction(-1)));

		x[4].add(new LinearCombination(new RootedPermutation(new int[]{2,1,3,4},new int[]{1,3}),new Fraction(1)));
		x[4].add(new LinearCombination(new RootedPermutation(new int[]{3,1,2,4},new int[]{1,3}),new Fraction(-1)));

		x[4].add(new LinearCombination(new RootedPermutation(new int[]{3,1,4,2},new int[]{1,3}),new Fraction(1)));
		x[4].add(new LinearCombination(new RootedPermutation(new int[]{4,1,3,2},new int[]{1,3}),new Fraction(-1)));

		x[4].add(new LinearCombination(new RootedPermutation(new int[]{3,2,4,1},new int[]{0,2}),new Fraction(1)));
		x[4].add(new LinearCombination(new RootedPermutation(new int[]{3,1,4,2},new int[]{0,2}),new Fraction(-1)));

		x[4].add(new LinearCombination(new RootedPermutation(new int[]{4,2,1,3},new int[]{1,3}),new Fraction(1)));
		x[4].add(new LinearCombination(new RootedPermutation(new int[]{1,2,4,3},new int[]{1,3}),new Fraction(-1)));

		//For each i, y_i is obtained from x_i by "rotating" the permutation in each
		//individual term of x_i.
		LinearCombination[]y = new LinearCombination[5];
		for(int i=0; i<5; i++)
		{
			y[i]=x[i].copy();
			y[i].rotate();
		}

		//We record the coefficients of each rooted permutation in x_i so that we
		//can use the pre-computed multiplication table to quickly compute the
		//products x_i*x_j.
		Fraction[][]xVector=new Fraction[5][flagsOne.length];
		for(int i=0; i<5; i++)
		{
			for(int f=0; f<flagsOne.length; f++)
			{
				xVector[i][f]=new Fraction();
				for(int p=0; p<x[i].perms.size(); p++)
				{
					if(x[i].perms.get(p).same(flagsOne[f]))
					{
						xVector[i][f].add(x[i].coeffs.get(p));
					}
				}
			}
		}
		//We record the coefficients of each rooted permutation in y_i so that we
		//can use the pre-computed multiplication table to quickly compute the
		//products y_i*y_j.
		Fraction[][]yVector=new Fraction[5][flagsTwo.length];
		for(int i=0; i<5; i++)
		{
			for(int f=0; f<flagsTwo.length; f++)
			{
				yVector[i][f]=new Fraction();
				for(int p=0; p<y[i].perms.size(); p++)
				{
					if(y[i].perms.get(p).same(flagsTwo[f]))
					{
						yVector[i][f].add(y[i].coeffs.get(p));
					}
				}
			}
		}

		//We compute x_i*x_j as a linear combination of rooted permutations
		//for all i and j.
		LinearCombination[][]xProducts=new LinearCombination[5][5];

		for(int i=0; i<5; i++)
		{
			for(int j=0; j<5; j++)
			{
				xProducts[i][j]=new LinearCombination();
				for(int k=0; k<xVector[i].length; k++)
				{
					if(xVector[i][k].num!=0)
					{
						for(int m=0; m<xVector[j].length; m++)
						{
							if(xVector[j][m].num!=0)
							{
								LinearCombination term=multTableOne[k][m].copy();
								term.multiply(xVector[i][k]);
								term.multiply(xVector[j][m]);
								xProducts[i][j].add(term);
							}
						}
					}
				}
				xProducts[i][j].collect();
				xProducts[i][j].reduce();
			}
		}

		//We compute y_i*y_j as a linear combination of rooted permutations
		//for all i and j.
		LinearCombination[][]yProducts=new LinearCombination[5][5];

		for(int i=0; i<5; i++)
		{
			for(int j=0; j<5; j++)
			{
				yProducts[i][j]=new LinearCombination();
				for(int k=0; k<yVector[i].length; k++)
				{
					if(yVector[i][k].num!=0)
					{
						for(int m=0; m<yVector[j].length; m++)
						{
							if(yVector[j][m].num!=0)
							{
								LinearCombination term=multTableTwo[k][m].copy();
								term.multiply(yVector[i][k]);
								term.multiply(yVector[j][m]);
								yProducts[i][j].add(term);
							}
						}
					}
				}
				yProducts[i][j].collect();
				yProducts[i][j].reduce();
			}
		}

		//Printing out all of the products x_i*x_j for i<=j
		for(int i=0; i<5; i++)
		{
			for(int j=i; j<5; j++)
			{
				System.out.print("x_"+(i+1)+"*x_"+(j+1)+" = "+xProducts[i][j].print());
				System.out.println();
				System.out.println();
			}
		}

		//Printing out all of the products y_i*y_j for i<=j
		for(int i=0; i<5; i++)
		{
			for(int j=i; j<5; j++)
			{
				System.out.print("y_"+(i+1)+"*y_"+(j+1)+" = "+yProducts[i][j].print());
				System.out.println();
				System.out.println();
			}
		}

		//Computing [[x_i*x_j]] for all i and j.
		LinearCombination[][]xUnrootedProducts=new LinearCombination[5][5];

		for(int i=0; i<5; i++)
		{
			for(int j=0; j<5; j++)
			{
				xUnrootedProducts[i][j]=xProducts[i][j].copy();
				xUnrootedProducts[i][j].unroot();
				xUnrootedProducts[i][j].collect();
				xUnrootedProducts[i][j].reduce();
			}
		}

		//Computing [[y_i*y_j]] for all i and j.
		LinearCombination[][]yUnrootedProducts=new LinearCombination[5][5];

		for(int i=0; i<5; i++)
		{
			for(int j=0; j<5; j++)
			{
				yUnrootedProducts[i][j]=yProducts[i][j].copy();
				yUnrootedProducts[i][j].unroot();
				yUnrootedProducts[i][j].collect();
				yUnrootedProducts[i][j].reduce();
			}
		}

		//Printing out [[x_i*x_j]] for all i and j such that i<=j.
		for(int i=0; i<5; i++)
		{
			for(int j=i; j<5; j++)
			{
				System.out.print("[[x_"+(i+1)+"*x_"+(j+1)+"]] = "+xUnrootedProducts[i][j].print());
				System.out.println();
				System.out.println();
			}
		}

		//Printing out [[y_i*y_j]] for all i and j such that i<=j.
		for(int i=0; i<5; i++)
		{
			for(int j=i; j<5; j++)
			{
				System.out.print("[[y_"+(i+1)+"*y_"+(j+1)+"]] = "+yUnrootedProducts[i][j].print());
				System.out.println();
				System.out.println();
			}
		}

		//We hard-code the matrix M.
		Fraction[][]M=new Fraction[5][5];
		M[0][0]=new Fraction(86,112);
		M[0][1]=new Fraction(6,112);
		M[0][2]=new Fraction(40,112);
		M[0][3]=new Fraction(40,112);
		M[0][4]=new Fraction(-40,112);
		M[1][1]=new Fraction(136,112);
		M[1][2]=new Fraction(46,112);
		M[1][3]=new Fraction(46,112);
		M[1][4]=new Fraction(-46,112);
		M[2][2]=new Fraction(101,112);
		M[2][3]=new Fraction(-17,112);
		M[2][4]=new Fraction(-38,112);
		M[3][3]=new Fraction(101,112);
		M[3][4]=new Fraction(-46,112);
		M[4][4]=new Fraction(101,112);
		for(int i=0; i<5; i++)
		{
			for(int j=0; j<i; j++)
			{
				M[i][j]=M[j][i].copy();
			}
		}

		//Computing sum_{pi in S_6} d(rhoStar, pi)*pi - [[x*M*x^T]] - [[y*M*y^T]]
		//as a formal linear combination of permutations in S_6.
		LinearCombination result=new LinearCombination();
		result.add(rhoStarDensity);
		for(int i=0; i<5; i++)
		{
			for(int j=0; j<5; j++)
			{
				LinearCombination xTerm=xUnrootedProducts[i][j].copy();
				xTerm.multiply(M[i][j]);
				xTerm.multiply(-1);
				result.add(xTerm);

				LinearCombination yTerm=yUnrootedProducts[i][j].copy();
				yTerm.multiply(M[i][j]);
				yTerm.multiply(-1);
				result.add(yTerm);
			}
		}
		result.collect();
		result.reduce();
		//Printing sum_{pi in S_6} d(rhoStar, pi)*pi - [[x*M*x^T]] - [[y*M*y^T]].
		System.out.println("sum_{pi in S_6} d(rhoStar, pi)*pi - [[x*M*x^T]] - [[y*M*y^T]] = "+result.print());

	}

	//A method for computing d(rhoStar,pi) for a permutation pi.
	public static Fraction rhoStarDensity(int[]pi)
	{
		Fraction result=new Fraction();
		result.add(density(new int[]{2,4,1,3},pi));
		result.add(density(new int[]{3,1,4,2},pi));
		result.denom=result.denom*2;
		result.add(density(new int[]{1,2,3},pi));
		result.add(density(new int[]{3,2,1},pi));
		result.add(density(new int[]{2,1,4,3},pi));
		result.add(density(new int[]{3,4,1,2},pi));
		return result;
	}

	//A method for computing d(sigma,pi) for two permutations sigma and pi
	public static Fraction density(int[]sigma,int[]pi)
	{
		if(sigma.length>pi.length)
		{
			return new Fraction();
		}
		int count=0;
		int[]set=new int[sigma.length];
		for(int i=0; i<set.length; i++)
		{
			set[i]=i;
		}
		while(set[0]>=0)
		{
			boolean good=true;
			for(int i=0; i<set.length; i++)
			{
				for(int j=i+1; j<set.length; j++)
				{
					if((sigma[i]-sigma[j])*(pi[set[i]]-pi[set[j]])<=0)
					{
						good=false;
					}
				}
			}
			if(good)
			{
				count++;
			}
			RootedPermutation.update(set,pi.length);
		}
		return new Fraction(count, RootedPermutation.binom(pi.length,sigma.length));
	}
}
