/*This program defines "LinearCombination" objects, which consist of a list
of rooted permutations and a list of coefficients. This represents a formal
linear combination of rooted permutations.*/

import java.util.ArrayList;

public class LinearCombination
{
	public ArrayList<RootedPermutation>perms;
	public ArrayList<Fraction>coeffs;

	//Constructor methods
	public LinearCombination()
	{
		perms=new ArrayList<RootedPermutation>();
		coeffs=new ArrayList<Fraction>();
  }
	public LinearCombination(RootedPermutation perm, Fraction coeff)
	{
		perms=new ArrayList<RootedPermutation>();
		perms.add(perm);
		coeffs=new ArrayList<Fraction>();
		coeffs.add(coeff);
  }

	public LinearCombination(ArrayList<RootedPermutation> thePerms, ArrayList<Fraction> theCoeffs)
	{
		perms=thePerms;
		coeffs=theCoeffs;
  }

	//A method for adding two linear combinations of rooted permutations.
	public void add(LinearCombination x)
	{
		for(int p=0; p<x.perms.size(); p++)
		{
			perms.add(x.perms.get(p));
			coeffs.add(x.coeffs.get(p));
		}
	}

	public void multiply(Fraction x)
	{
		for(int i=0; i<coeffs.size(); i++)
		{
			coeffs.get(i).multiply(x);
		}
	}

	public void multiply(int x)
	{
		for(int i=0; i<coeffs.size(); i++)
		{
			coeffs.get(i).multiply(x);
		}
	}

	//A method for collecting terms in a linear combination of rooted
	//permutations.
	public void collect()
	{
		for(int i=0; i<perms.size(); i++)
		{
			for(int j=perms.size()-1; j>=i+1; j--)
			{
				if(perms.get(i).same(perms.get(j)))
				{
					coeffs.get(i).add(coeffs.get(j));
					coeffs.remove(j);
					perms.remove(j);
				}
			}
		}
		for(int i=perms.size()-1; i>=0; i--)
		{
			if(coeffs.get(i).num==0)
			{
				perms.remove(i);
				coeffs.remove(i);
			}
		}
	}

	public void reduce()
	{
		for(int i=0; i<coeffs.size(); i++)
		{
			coeffs.get(i).reduce();
		}
	}

	public void unroot()
	{
		for(int p=0; p<perms.size(); p++)
		{
			coeffs.get(p).denom = coeffs.get(p).denom*RootedPermutation.binom(perms.get(p).length(),perms.get(p).numRoots());
			perms.get(p).roots=new int[0];
		}
	}

	public void rotate()
	{
		for(int p=0; p<perms.size(); p++)
		{
			perms.get(p).rotate();
		}
	}

	public String print()
	{
		String output="";
		for(int p=0; p<perms.size(); p++)
		{
			if(p>0)
			{
				output=output+" + ";
			}
			output=output+"(";
			output=output+coeffs.get(p).print();
			output=output+")*";
			output=output+perms.get(p).print();
		}
		return output;
	}

	public LinearCombination copy()
	{
		ArrayList<RootedPermutation>newPerms=new ArrayList<RootedPermutation>();
		ArrayList<Fraction>newCoeffs=new ArrayList<Fraction>();

		for(int p=0; p<perms.size(); p++)
		{
			newPerms.add(perms.get(p).copy());
			newCoeffs.add(coeffs.get(p).copy());
		}
		return new LinearCombination(newPerms,newCoeffs);
	}
}
