/*This is a very unsophisticated program for performing arithmetic operations
involving rational numbers.*/

public class Fraction
{
	long num;
	long denom;

	//Constructor methods
	public Fraction()
	{
		num=0;
		denom=1;
	}
	public Fraction(int a, int b)
	{
    num=(long)a;
		denom=(long)b;
  }

	public Fraction(int a)
	{
		num=(long)a;
		denom=1;
	}

	public Fraction(long a)
	{
		num=a;
		denom=1;
	}
	public Fraction(long a, long b)
	{
    num=a;
		denom=b;
		if(num==0)
		{
			denom=1;
		}
  }

	public void add(Fraction x)
	{
		long d=gcd(denom,x.denom);
		long lcm=(denom*x.denom)/d;

		num=num*(lcm/denom) + x.num*(lcm/x.denom);
		denom=lcm;
	}

	public void multiply(Fraction x)
	{
		num=num*x.num;
		denom=denom*x.denom;
		if(num==0)
		{
			denom=1;
		}
	}

	public void add(long x)
	{
		this.add(new Fraction(x,1));
	}

	public void multiply(long x)
	{
		this.multiply(new Fraction(x,1));
	}

	public void reduce()
	{
		if(denom<0)
		{
			num=(-1)*num;
			denom=(-1)*denom;
		}
		if(num==0)
		{
			denom=1;
			return;
		}

		long d=gcd(num,denom);
		num=num/d;
		denom=denom/d;
	}

	public Fraction copy()
	{
		return new Fraction(num,denom);
	}

	//A simple method for using the Euclidean algorithm to determine the
	//greatest common divisor of two longegers.
	public static long gcd(long a, long b)
	{
		if(a<0)
		{
			return gcd((-1)*a,b);
		}
		if(b<0)
		{
			return gcd(a,(-1)*b);
		}

		long q=(a/b);
		long r=a-(b*q);
		if(r==0)
		{
			return b;
		}
		return gcd(b,r);
	}

	public String print()
	{
		return ""+num+"/"+denom;
	}
}
